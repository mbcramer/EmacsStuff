import re
## /usr/share/gdb/python/gdb is the path to the python gdb package
import gdb
import sys
print(sys.version)

## If debugging this pretty printer, we might load this module/ script a number of times
##  This deletes the old version, so we can find the new one when printing.
i = 0;
for p in gdb.pretty_printers:
    if hasattr(p, "__name__") and p.__name__ == "GpLookupFunction":
        print("Deleting old printer: :%s:" % p.__name__)
        del gdb.pretty_printers[i]




scalarSet = set(["bool",
                 "char",
                 "signed char",
                 "unsigned char",
                 "short",
                 "short int",
                 "signed short",
                 "signed short int",
                 "unsigned short",
                 "unsigned short int",
                 "int",
                 "signed",
                 "signed int",
                 "unsigned",
                 "unsigned int",
                 "long",
                 "long int",
                 "signed long",
                 "signed long int",
                 "unsigned long",
                 "unsigned long int",
                 "long long",
                 "long long int",
                 "signed long long",
                 "signed long long int",
                 "unsigned long long",
                 "unsigned long long int",
                 "float",
                 "double",
                 "long double"
             ])

baseClassSet =set([])

gpEnabled = True
gpDebug  = False
gpRunTimeType = False # // Setting this to true makes it impossible to print just the base class of a derived class
gpIndent = 0

class GenericPrinter(object):
    "more friendly object printer"
    def __init__(self,val):
        global scalarSet
        global baseClassSet
        self.val = val

#########################################################################
    def to_string(self):
        rv = str(self.val.type)
        return rv

#########################################################################
    def yielder(self,field):
        global gpIndent
        # existance of the bitpos attr is the best substitute I could find
        # to identify static members of a class
        if gpDebug:
            print("\nyielder:BEGIN:"+field.name +":"+str(field.type.strip_typedefs()))

        if (not hasattr(field,'bitpos')) and (not gdb.parameter("print static")):
            if gpDebug:
                print("\nused to return early")
            #    print("\nDBG:returning early")
            #return

        spaces = " " * gpIndent

        if field.type.code == gdb.TYPE_CODE_PTR:
            if gpDebug:
                print("\npointer:"+field.name)
            yield field.name,"("+str(field.type) + ") " + str(self.val[field.name])
        elif self.isScalar(field.type.strip_typedefs()):
            if gpDebug:
                print("\nscalar:"+field.name+":"+str(field.type.strip_typedefs()))
            yield field.name,self.val[field.name]
        elif field.is_base_class and self.isPrintableBaseClass(field.type):
            if gpDebug:
                print("\nBaseClass:"+field.name)

            for k,v in self.PrintBaseClass(field):
                #print("\nMBC:" + k + ":\n")
                yield  k , v
        else:
            if gpDebug:
                print("\nFinalElse:"+field.name)
            yield field.name, "{" + str(field.type) + "}"

        if gpDebug:
            print("\nyielder:END:"+field.name +":"+str(field.type.strip_typedefs()))

#########################################################################
    def PrintBaseClass(self,bcfield):
        global gpIndent
        gpIndent += 2

        if gpDebug:
            print("\nPrintBaseClass:BEGIN:"+bcfield.name)

        spaces = " " * gpIndent

        gdb.write(" {\n" + spaces + bcfield.name + "(base class)")
        if len(bcfield.type.fields()) == 0:
            gpIndent -= 2
            return
        oldVal = self.val
        addr = self.val.address
        addr2 = addr.dynamic_cast(bcfield.type.pointer())
        v = addr2.dereference()
        self.val = v

        for fld in bcfield.type.fields():
            for k,v in self.yielder(fld):
                #print("\nMBC:" + k + ":\n")
                yield  (" "*2) + k , v

        gdb.write("\n" + spaces +"}")
        self.val = oldVal
        gpIndent -= 2
        if gpDebug:
            print("\nPrintBaseClass:END:"+bcfield.name)


#########################################################################
    def children(self):
        global gpDebug
        if gpDebug:
            print("\n"+str(self.val.dynamic_type))

        if gpRunTimeType:
            fields = self.val.dynamic_type.fields()
        else:
            fields = self.val.type.fields()

        for field in fields:
            if gpDebug:
                print("\nfield:%s:" % field.name)
                print("\n type:%s:" % str(field.type))
                print("\nstrip:%s:\n" % field.type.strip_typedefs())
            for k,v in self.yielder(field):
                yield k,v

#########################################################################
    def isScalar(self,val):
##        print "type is:%s:" % str(val)
        if str(val) in scalarSet:
            return True
        return False

#########################################################################
    def isPrintableBaseClass(self,val):
        if gpDebug:
            print ("type is:%s:" % str(val))
        if str(val) in baseClassSet:
            return True
        return False

#########################################################################
def GpLookupFunction(val):
    global gpEnabled

    lookup_tag = val.type.tag

    if lookup_tag == None:
        return None

    if not gpEnabled:
        return None

    if val.type.code == gdb.TYPE_CODE_STRUCT:
        regex = re.compile("^rtmd::BeatTimestamp$")
        if regex.match(lookup_tag):
            return BeatTimestampPrinter(val)

        regex = re.compile("^QString$")
        if regex.match(lookup_tag):
            return QStringPrinter(val)

        regex = re.compile("^rtmd::Timestamp$")
        if regex.match(lookup_tag):
            return TimestampPrinter(val)

        regex = re.compile("^ref_ptr")
        if regex.match(lookup_tag):
            return RefPtrPrinter(val)

        return GenericPrinter(val)
    return None

##  ref_ptr Printer
class RefPtrPrinter(object):
    "print ref_ptr"
    def __init__(self,val):
        self.val = val

    def to_string(self):
        myval = self.val['_inst']
        return "ref_ptr to (" + str(myval.type) + ") " + str(myval)

    def display_hint(self):
        return 'ref_ptr'

##  BeatTimestampPrinter
class BeatTimestampPrinter(object):
    "print beat timestamp"
    def __init__(self,val):
        self.val = val

    def to_string(self):
        for field in self.val.type.fields():
            newval = self.val.cast(gdb.lookup_type("rtmd::Timestamp_tmpl<rtmd::BeatTimestamp_FTOR>"))
            return newval["_ts"]

    def display_hint(self):
        return 'string'

## TimestampPrinter
class TimestampPrinter(object):
    "print timestamp printer"
    def __init__(self,val):
        self.val = val

    def to_string(self):
        for field in self.val.type.fields():
            newval = self.val.cast(gdb.lookup_type("rtmd::Timestamp_tmpl<rtmd::Timestamp_FTOR>"))
            return newval["_ts"]

    def display_hint(self):
        return 'string'





class QStringPrinter(object):
    "Print a QString"
    def __init__(self,val):
        self.val = val

    def to_string(self):
        rv = ""
        n = self.val['d']['size']
        for i in range(n):
            rv+=str(chr(self.val['d']['data'][i]))
        return rv

    def display_hint(self):
        return 'string'

#def QStringPrinter(val):
#    lookup_tag = val.type.tag
#    if lookup_tag == None:
#        return None
#    regex = re.compile("^QString$")
#    if regex.match(lookup_tag):
#        return QStringPrinter(val)
#    return None


# initialization and other commands
gdb.pretty_printers.append(GpLookupFunction)

class gpListScalars (gdb.Command):
    """List the types to be treated as scalars"""
    global scalarSet

    def __init__ (self):
        super (gpListScalars, self).__init__ ("gpListScalars", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        print( "gpEnabled=%s" % gpEnabled)
        for index,item in enumerate(scalarSet):
            print( "%s" % item)




class gpAddScalar (gdb.Command):
    """Add a type to be treated as a scalar value"""
    global scalarSet

    def __init__ (self):
        super (gpAddScalar, self).__init__ ("gpAddScalar", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        scalarSet.add(str(gdb.lookup_type(arg).strip_typedefs()))

class gpAddBaseClass (gdb.Command):
    """Add a class to be printed when ref'd as a base class"""
    global baseClassSet

    def __init__ (self):
        super (gpAddBaseClass, self).__init__ ("gpAddBaseClass", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        baseClassSet.add(str(gdb.lookup_type(arg).strip_typedefs()))

class gpEnableDisable (gdb.Command):
    """Toggles between enabled and disabled"""
    global gpEnabled

    def __init__ (self):
        super (gpEnableDisable, self).__init__ ("gpEnableDisable", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        global gpEnabled
        gpEnabled = not gpEnabled

class gpToggleDebug (gdb.Command):
    """enables generic printer debug"""
    global gpDebug

    def __init__ (self):
        super (gpToggleDebug, self).__init__ ("gpToggleDebug", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        global gpDebug
        gpDebug = not gpDebug


class gpToggleRunTimeType (gdb.Command):
    """Toggles the boolean which allows us to use runtime type info"""
    global gpDebug

    def __init__ (self):
        super (gpToggleRunTimeType, self).__init__ ("gpToggleRunTimeType", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        global gpRunTimeType
        gpRunTimeType = not gpRunTimeType


class gpRemoveScalar (gdb.Command):
    """Remove a type to be treated as a scalar value"""
    global scalarSet

    def __init__ (self):
        super (gpRemoveScalar, self).__init__ ("gpRemoveScalar", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        scalarSet.remove(str(gdb.lookup_type(arg).strip_typedefs()))


class gpListBaseClasses (gdb.Command):
    """List the bases classes which are printed automatically when ref'd as base class"""
    global baseClassSet

    def __init__ (self):
        super (gpListBaseClasses, self).__init__ ("gpListBaseClasses", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        print( "gpEnabled=%s" % gpEnabled)
        for index,item in enumerate(baseClassSet):
            print( "%s" % item)

class gpAddBaseClass (gdb.Command):
    """Add a base class which is printed automatically when ref'd as a base class"""
    global baseClassSet

    def __init__ (self):
        super (gpAddBaseClass, self).__init__ ("gpAddBaseClass", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        baseClassSet.add(str(gdb.lookup_type(arg).strip_typedefs()))

class gpRemoveBaseClass (gdb.Command):
    """Remove a base class from those that are printed automatically when ref'd as a base class"""
    global scalarSet

    def __init__ (self):
        super (gpRemoveBaseClass, self).__init__ ("gpRemoveBaseClass", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        baseClassSet.remove(str(gdb.lookup_type(arg).strip_typedefs()))


class gpPrintRealType (gdb.Command):
    """print the true type of the object, rather than the declared type"""

    def __init__ (self):
        super (gpPrintRealType, self).__init__ ("gpPrintRealType", gdb.COMMAND_USER)

    def invoke (self, arg, from_tty):
        global gpRunTimeType
        gpRunTimeType = True;
        gdb.execute("print " + arg)
        gpRunTimeType = False;
        #for method_name in dir(gdb):
        #    if callable(getattr(gdb,method_name)):
        #        print method_name



        ##print("path:%s:" % sys.path)
##        gdb.print(arg)

gpListScalars ()
gpAddScalar ()
gpRemoveScalar ()
gpEnableDisable()
gpToggleDebug()
gpListBaseClasses()
gpAddBaseClass()
gpRemoveBaseClass()
#gpToggleRunTimeType()
gpPrintRealType()
